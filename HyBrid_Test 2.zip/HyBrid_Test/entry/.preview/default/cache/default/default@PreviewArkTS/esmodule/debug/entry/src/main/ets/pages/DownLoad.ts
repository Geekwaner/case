if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface DownLoad_Params {
}
import request from "@ohos:request";
import zlib from "@ohos:zlib";
import fileIo from "@ohos:file.fs";
import router from "@ohos:router";
class DownLoad extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: DownLoad_Params) {
    }
    updateStateVars(params: DownLoad_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    async hotReload() {
        try {
            // 下载 沙箱目录 => 判断沙箱目录是否有重复的地址
            // toutiao.zip
            const fileName = "toutiao.zip";
            const filePath = getContext().filesDir + "/" + fileName;
            // 检查一下 当下目录有没有相同的文件
            if (fileIo.listFileSync(getContext().filesDir).includes(fileName)) {
                // 此时说明已经存在这个文件了
                // 直接讲该文件重命名
                fileIo.renameSync(filePath, getContext().filesDir + "/toutiao.bak.zip");
            }
            const task = await request.downloadFile(getContext(), {
                url: 'https://gitee.com/shuiruohanyu/toutiao_net/raw/master/resources/toutiao.zip',
                filePath // 要存储的沙箱目录
            });
            task.on("complete", async () => {
                await zlib.decompressFile(filePath, getContext().filesDir);
                AlertDialog.show({ message: '解压完成' });
                router.pushUrl({
                    url: 'pages/WebHybrid'
                });
            });
        }
        catch (error) {
            AlertDialog.show({ message: error.message });
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            RelativeContainer.create();
            RelativeContainer.debugLine("entry/src/main/ets/pages/DownLoad.ets(40:5)", "entry");
            RelativeContainer.height('100%');
            RelativeContainer.width('100%');
        }, RelativeContainer);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("热更新");
            Button.debugLine("entry/src/main/ets/pages/DownLoad.ets(41:7)", "entry");
            Button.id('DownLoadHelloWorld');
            Button.fontSize(50);
            Button.fontWeight(FontWeight.Bold);
            Button.alignRules({
                center: { anchor: '__container__', align: VerticalAlign.Center },
                middle: { anchor: '__container__', align: HorizontalAlign.Center }
            });
            Button.onClick(() => {
                this.hotReload();
            });
        }, Button);
        Button.pop();
        RelativeContainer.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "DownLoad";
    }
}
registerNamedRoute(() => new DownLoad(undefined, {}), "", { bundleName: "com.itheima.fast.driver.myapplication", moduleName: "entry", pagePath: "pages/DownLoad", pageFullPath: "entry/src/main/ets/pages/DownLoad", integratedHsp: "false" });
