if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ConnectPage_Params {
    controller?: webview.WebviewController;
    ports?: webview.WebMessagePort[];
    name?: string;
}
import webview from "@ohos:web.webview";
class ConnectPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.controller = new webview.WebviewController();
        this.ports = [];
        this.__name = new ObservedPropertySimplePU("", this, "name");
        this.setInitiallyProvidedValue(params);
        this.declareWatch("name", this.updateName);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ConnectPage_Params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.ports !== undefined) {
            this.ports = params.ports;
        }
        if (params.name !== undefined) {
            this.name = params.name;
        }
    }
    updateStateVars(params: ConnectPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__name.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__name.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private controller: webview.WebviewController;
    private ports: webview.WebMessagePort[];
    private __name: ObservedPropertySimplePU<string>;
    get name() {
        return this.__name.get();
    }
    set name(newValue: string) {
        this.__name.set(newValue);
    }
    createPorts() {
        this.ports = this.controller.createWebMessagePorts(); // 有两个端口
        if (this.ports.length) {
            this.controller.postMessage("trans_port", [this.ports[1]], "*");
            // 必须有接收才能发送
            this.ports[0].onMessageEvent((event) => {
                AlertDialog.show({ message: event.toString() });
            });
        }
    }
    // 只要内容变化 就会触发逻辑
    updateName() {
        this.ports[0].postMessageEvent(this.name);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            RelativeContainer.create();
            RelativeContainer.debugLine("entry/src/main/ets/pages/ConnectPage.ets(29:5)", "entry");
            RelativeContainer.height('100%');
            RelativeContainer.width('100%');
        }, RelativeContainer);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("发送消息");
            Button.debugLine("entry/src/main/ets/pages/ConnectPage.ets(30:7)", "entry");
            Button.id("btn1");
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入内容', text: { value: this.name, changeEvent: newValue => { this.name = newValue; } } });
            TextInput.debugLine("entry/src/main/ets/pages/ConnectPage.ets(32:7)", "entry");
            TextInput.id("text1");
            TextInput.alignRules({
                top: {
                    anchor: 'btn1',
                    align: VerticalAlign.Bottom
                }
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Web.create({
                src: { "id": 0, "type": 30000, params: ["index.html"], "bundleName": "com.itheima.fast.driver.myapplication", "moduleName": "entry" },
                controller: this.controller
            });
            Web.debugLine("entry/src/main/ets/pages/ConnectPage.ets(40:7)", "entry");
            Web.alignRules({
                top: {
                    anchor: 'text1',
                    align: VerticalAlign.Bottom
                }
            });
            Web.onAlert((res) => {
                AlertDialog.show({ message: res.message });
                return true;
            });
            Web.onPageEnd(() => {
                this.createPorts();
            });
        }, Web);
        RelativeContainer.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ConnectPage";
    }
}
registerNamedRoute(() => new ConnectPage(undefined, {}), "", { bundleName: "com.itheima.fast.driver.myapplication", moduleName: "entry", pagePath: "pages/ConnectPage", pageFullPath: "entry/src/main/ets/pages/ConnectPage", integratedHsp: "false" });
