if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ConnectPageNB_Params {
    // controller: webview.WebviewController = new webview.WebviewController()
    obj?: WebSdk;
}
import webview from "@ohos:web.webview";
import picker from "@ohos:multimedia.cameraPicker";
import camera from "@ohos:multimedia.camera";
import type common from "@ohos:app.ability.common";
import type { BusinessError } from "@ohos:base";
let mContext = getContext(this) as common.Context;
class ConnectPageNB extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.obj = new WebSdk();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ConnectPageNB_Params) {
        if (params.obj !== undefined) {
            this.obj = params.obj;
        }
    }
    updateStateVars(params: ConnectPageNB_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // controller: webview.WebviewController = new webview.WebviewController()
    private obj: WebSdk;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            RelativeContainer.create();
            RelativeContainer.debugLine("entry/src/main/ets/pages/ConnectPageNB.ets(17:5)", "entry");
            RelativeContainer.height('100%');
            RelativeContainer.width('100%');
        }, RelativeContainer);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("发送消息");
            Button.debugLine("entry/src/main/ets/pages/ConnectPageNB.ets(18:7)", "entry");
            Button.id("btn1");
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Web.create({
                src: { "id": 0, "type": 30000, params: ["kit.html"], "bundleName": "com.itheima.fast.driver.myapplication", "moduleName": "entry" },
                controller: this.obj.controller
            });
            Web.debugLine("entry/src/main/ets/pages/ConnectPageNB.ets(21:7)", "entry");
            Web.alignRules({
                top: {
                    anchor: 'text1',
                    align: VerticalAlign.Bottom
                }
            });
            Web.javaScriptProxy({
                name: 'hm',
                methodList: ["showToast", "takePhoto", "getLocation"],
                controller: this.obj.controller,
                object: this.obj // new 构造一个类
            });
            Web.fileAccess(true);
            Web.onAlert((res) => {
                AlertDialog.show({ message: res.message });
                return true;
            });
            Web.onPageEnd(() => {
            });
        }, Web);
        RelativeContainer.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ConnectPageNB";
    }
}
class WebSdk {
    controller: webview.WebviewController = new webview.WebviewController(); // 自己造一个controller
    // 弹窗
    showToast(message: string) {
        AlertDialog.show({ message });
    }
    // 拍照
    async takePhoto(funcName: string) {
        // 把拍照的照片给h5 去显示呢
        try {
            let pickerProfile: picker.PickerProfile = {
                cameraPosition: camera.CameraPosition.CAMERA_POSITION_BACK
            };
            let pickerResult: picker.PickerResult = await picker.pick(mContext, [picker.PickerMediaType.PHOTO, picker.PickerMediaType.VIDEO], pickerProfile);
            this.controller.runJavaScript(`${funcName}('${pickerResult.resultUri}')`);
            // AlertDialog.show({ message: JSON.stringify(pickerResult) })
        }
        catch (error) {
            let err = error as BusinessError;
            console.error(`the pick call failed. error code: ${err.code}`);
        }
    }
    // 获取定位
    getLocation() {
    }
}
registerNamedRoute(() => new ConnectPageNB(undefined, {}), "", { bundleName: "com.itheima.fast.driver.myapplication", moduleName: "entry", pagePath: "pages/ConnectPageNB", pageFullPath: "entry/src/main/ets/pages/ConnectPageNB", integratedHsp: "false" });
