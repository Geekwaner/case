if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LazyForEachCase_Params {
    list?: ListDataSource;
}
class LazyForEachCase extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__list = new ObservedPropertyObjectPU(new ListDataSource(), this, "list");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LazyForEachCase_Params) {
        if (params.list !== undefined) {
            this.list = params.list;
        }
    }
    updateStateVars(params: LazyForEachCase_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__list.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__list.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __list: ObservedPropertyObjectPU<ListDataSource>;
    get list() {
        return this.__list.get();
    }
    set list(newValue: ListDataSource) {
        this.__list.set(newValue);
    }
    aboutToAppear(): void {
        // Array.from(Array(20)).forEach((item: number, index: number) => {
        //   this.list.pushData({ value: index + 1 } as Item)
        // })
        this.list.reloadData(Array.from(Array(20), (_: number, index: number) => {
            return { value: index + 1 } as Item;
        }));
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            RelativeContainer.create();
            RelativeContainer.debugLine("entry/src/main/ets/pages/LazyForEachCase.ets(19:5)", "entry");
            RelativeContainer.height('100%');
            RelativeContainer.width('100%');
        }, RelativeContainer);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 20 });
            List.debugLine("entry/src/main/ets/pages/LazyForEachCase.ets(20:7)", "entry");
        }, List);
        {
            const __lazyForEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(() => { }, false);
                        ListItem.width("100%");
                        ListItem.height(100);
                        ListItem.backgroundColor(Color.Blue);
                        ListItem.onAppear(() => {
                            console.log(item.value + "项开始渲染");
                        });
                        ListItem.onDisAppear(() => {
                            console.log(item.value + "项开始销毁");
                        });
                        ListItem.debugLine("entry/src/main/ets/pages/LazyForEachCase.ets(22:11)", "entry");
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation2(itemCreation2, ListItem);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.value.toString());
                            Text.debugLine("entry/src/main/ets/pages/LazyForEachCase.ets(23:13)", "entry");
                            Text.fontSize(30);
                            Text.fontColor(Color.White);
                            Text.width("100%");
                            Text.textAlign(TextAlign.Center);
                        }, Text);
                        Text.pop();
                        ListItem.pop();
                    };
                    observedDeepRender();
                }
            };
            LazyForEach.create("1", this, this.list, __lazyForEachItemGenFunction);
            LazyForEach.pop();
        }
        List.pop();
        RelativeContainer.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "LazyForEachCase";
    }
}
// Basic implementation of IDataSource to handle data listener
class BasicDataSource implements IDataSource {
    private listeners: DataChangeListener[] = [];
    private originDataArray: object[] = [];
    public totalCount(): number {
        return 0;
    }
    public getData(index: number): object {
        return this.originDataArray[index];
    }
    // 该方法为框架侧调用，为LazyForEach组件向其数据源处添加listener监听
    registerDataChangeListener(listener: DataChangeListener): void {
        if (this.listeners.indexOf(listener) < 0) {
            console.info('add listener');
            this.listeners.push(listener);
        }
    }
    // 该方法为框架侧调用，为对应的LazyForEach组件在数据源处去除listener监听
    unregisterDataChangeListener(listener: DataChangeListener): void {
        const pos = this.listeners.indexOf(listener);
        if (pos >= 0) {
            console.info('remove listener');
            this.listeners.splice(pos, 1);
        }
    }
    // 通知LazyForEach组件需要重载所有子组件
    notifyDataReload(): void {
        this.listeners.forEach(listener => {
            listener.onDataReloaded();
        });
    }
    // 通知LazyForEach组件需要在index对应索引处添加子组件
    notifyDataAdd(index: number): void {
        this.listeners.forEach(listener => {
            listener.onDataAdd(index);
        });
    }
    // 通知LazyForEach组件在index对应索引处数据有变化，需要重建该子组件
    notifyDataChange(index: number): void {
        this.listeners.forEach(listener => {
            listener.onDataChange(index);
        });
    }
    // 通知LazyForEach组件需要在index对应索引处删除该子组件
    notifyDataDelete(index: number): void {
        this.listeners.forEach(listener => {
            listener.onDataDelete(index);
        });
    }
    // 通知LazyForEach组件将from索引和to索引处的子组件进行交换
    notifyDataMove(from: number, to: number): void {
        this.listeners.forEach(listener => {
            listener.onDataMove(from, to);
        });
    }
}
// 封装自己的dataSource
class ListDataSource extends BasicDataSource {
    private dataArray: object[] = [];
    public totalCount(): number {
        return this.dataArray.length;
    }
    public getData(index: number): object {
        return this.dataArray[index];
    }
    public addData(index: number, data: object): void {
        this.dataArray.splice(index, 0, data);
        this.notifyDataAdd(index);
    }
    public pushData(data: object): void {
        this.dataArray.push(data);
        this.notifyDataAdd(this.dataArray.length - 1);
    }
    public reloadData(data: object[]): void {
        this.dataArray = data; // 直接赋值
        this.notifyDataReload();
        // this.dataArray.push(data);
        // this.notifyDataAdd(this.dataArray.length - 1);
    }
}
class Item {
    value: number = 0;
}
registerNamedRoute(() => new LazyForEachCase(undefined, {}), "", { bundleName: "com.itheima.fast.driver.myapplication", moduleName: "entry", pagePath: "pages/LazyForEachCase", pageFullPath: "entry/src/main/ets/pages/LazyForEachCase", integratedHsp: "false" });
