if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface WebHybrid_Params {
    message?: string;
}
import webview from "@ohos:web.webview";
class WebHybrid extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__message = new ObservedPropertySimplePU('Hello World', this, "message");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: WebHybrid_Params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
    }
    updateStateVars(params: WebHybrid_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __message: ObservedPropertySimplePU<string>;
    get message() {
        return this.__message.get();
    }
    set message(newValue: string) {
        this.__message.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            RelativeContainer.create();
            RelativeContainer.debugLine("entry/src/main/ets/pages/WebHybrid.ets(9:5)", "entry");
            RelativeContainer.height('100%');
            RelativeContainer.width('100%');
        }, RelativeContainer);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Web.create({
                src: "file://" + getContext().filesDir + "/toutiao/index.html",
                controller: new webview.WebviewController()
            });
            Web.debugLine("entry/src/main/ets/pages/WebHybrid.ets(10:7)", "entry");
            Web.fileAccess(true);
            Web.domStorageAccess(true);
        }, Web);
        RelativeContainer.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "WebHybrid";
    }
}
registerNamedRoute(() => new WebHybrid(undefined, {}), "", { bundleName: "com.itheima.fast.driver.myapplication", moduleName: "entry", pagePath: "pages/WebHybrid", pageFullPath: "entry/src/main/ets/pages/WebHybrid", integratedHsp: "false" });
